function MySubmit() {
	var oForm = document.getElementById("MyForm");
	if (CType_CheckForm(oForm) == false) {
		return false;
	}

    var sData = "_do=cmd.run&cmd=config-view;port-mapping-view;vs " + $("#type").val() + ":" + $("#port").val();

	if ($('#enable').prop("checked")) {
        sData += ";service enable";
    } else {
        sData += ";no service enable";
    }

	if (! RQ_Post("/request.cgi", sData)) {
        return false;
    }

	return true;
}

