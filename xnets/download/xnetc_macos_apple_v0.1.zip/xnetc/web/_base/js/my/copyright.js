﻿
$(document).ready(function() {
	$('#copyright').html( '<div class="Container"><hr><p align="center"> 版权所有: LiXingang windgorain@163.com </p><p align="center"> LiXingang windgorain@163.com Copyright All rights reserved</p><br><br></div>');
});


