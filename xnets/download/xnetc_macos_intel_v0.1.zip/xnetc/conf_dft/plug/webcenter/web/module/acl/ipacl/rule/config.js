function MySubmit(list_name) {
	var oForm = document.getElementById("MyForm");
	if (CType_CheckForm(oForm) == false) {
		return false;
	}

    var sData = "_do=cmd.run&cmd=config-view;acl-view;ip-acl " + list_name;

    sData += ";rule " + $('#rule_id').val() + " " + $('input:radio[name=action]:checked').val();

    var protocol = $('#protocol').val();
    if (protocol != "") {
        sData += " -t " + protocol;
    }

    var ip = $('#sip').val();
    var mask = $('#smask').val();
    if (ip != "") {
        if (mask == "") mask = "0";
        sData += " -s " + ip + "/" + mask;
    } else {
        var str = $('#sip_pool').val();
        if (str != "") {
            sData += " -S " + str;
        }
    }

    ip = $('#dip').val();
    mask = $('#dmask').val();
    if (ip != "") {
        if (mask == "") mask = "0";
        sData += " -d " + ip + "/" + mask;
    } else {
        var str = $('#dip_pool').val();
        if (str != "") {
            sData += " -D " + str;
        }
    }

    port1 = $('#sport1').val();
    port2 = $('#sport2').val();
    if (port1 != "") {
        if (port2 == "") port2 = port1;
        if (parseInt(port1) > parseInt(port2)) {
            var tmp = port1; port1=port2;port2=tmp;
        }
        sData += " -p " + port1 + "/" + port2;
    } else {
        var str = $('#sport_pool').val();
        if (str != "") {
            sData += " -P " + str;
        }
    }

    port1 = $('#dport1').val();
    port2 = $('#dport2').val();
    if (port1 != "") {
        if (port2 == "") port2 = port1;
        if (parseInt(port1) > parseInt(port2)) {
            var tmp = port1; port1=port2;port2=tmp;
        }
        sData += " -o " + port1 + "/" + port2;
    } else {
        var str = $('#dport_pool').val();
        if (str != "") {
            sData += " -O " + str;
        }
    }

    str = $('#information').val();
    if (str != "") {
        sData += " -i \"" + str + "\"";
    }

	if (! RQ_Post("/request.cgi", sData)) {
        return false;
    }

	return true;
}

