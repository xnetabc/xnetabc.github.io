function MySubmit(list_name) {
	var oForm = document.getElementById("MyForm");
	if (CType_CheckForm(oForm) == false) {
		return false;
	}

    var sData = "_do=cmd.run&cmd=config-view;port-mapping-view;vs " + list_name;

    sData += ";rs " + $('#dip').val() + " " + $('#dport').val();

	if ($('#enable').prop("checked")) {
        sData += " enable";
    } else {
        sData += " disable";
    }

	if (! RQ_Post("/request.cgi", sData)) {
        return false;
    }

	return true;
}

